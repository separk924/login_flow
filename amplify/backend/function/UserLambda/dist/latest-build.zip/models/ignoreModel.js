const mongoose = require('mongoose');

const IgnoreSchema = new mongoose.Schema({
    address: {
        type: String,
        required: [true],
        unique: false,
    },
    old_businesses: [String],
});

module.exports = mongoose.model("Ignores", IgnoreSchema);