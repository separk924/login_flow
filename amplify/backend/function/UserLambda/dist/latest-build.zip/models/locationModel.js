const mongoose = require('mongoose');

const LocationSchema = new mongoose.Schema({
    businessName: {
        type: String,
        unique: false,
    },

    address: {
        type: String,
        unique: false,
    },

    status: {
        type: String,
        unique: false,
    },

    modifiedBy: {
        type: String,
        unique: false,
    },

    lastModified: {
        type: String,
        unique: false,
    },

    notes: {
        type: String,
        unique: false,
    },

    lastModifiedFromYelp: {
        type: String,
        unique: false,
    },

    lastModifiedFromGoogle: {
        type: String,
        unique: false,
    },

    lastModifiedFromBlatteis: {
        type: String,
        unique: false,
    },

    lastModifiedManual: {
        type: String,
        unique: false,
    },

    lastBusinessNameYelp: {
        type: String,
        unique: false,
    },

    lastStatusYelp: {
        type: String,
        unique: false,
    },

    lastBusinessNameGoogle: {
        type: String,
        unique: false,
    },

    lastStatusGoogle: {
        type: String,
        unique: false,
    },

    lastBusinessNameBlatteis: {
        type: String,
        unique: false,
    },

    lastStatusBlatteis: {
        type: String,
        unique: false,
    },

    lastBusinessNameManual: {
        type: String,
        unique: false,
    },

    lastStatusManual: {
        type: String,
        unique: false,
    },
    googleId: {
        type: String,
        unique: false,
    },
    yelpId: {
        type: String,
        unique: false,
    },
    index: {
        type: Number,
        unique: false,
    },
    streetname: {
        type: String,
        unique: false,
    },
    neighborhood: {
        type: String,
        unique: false,
    },
    suite: {
        type: String,
        unique: false,
    },
    floor: {
        type: String,
        unique: false,
    },
    "#": {
        type: String,
        unique: false,
    }
});

module.exports = mongoose.model("Locations", LocationSchema);