const mongoose = require('mongoose');

const NotifSchema = new mongoose.Schema({
    message: {
        type: String,
        required: [true],
        unique: false,
    },
    address: {
        type: String,
        required: [false],
        unique: false,
    },
    availability: {
        type: String,
        required: [false],
        unique: false,
    },
    date: {
        type: String,
        required: [false],
        unique: false,
    },
    opened: {
        type: Boolean,
        required: [true],
    },
    appeared: {
        type: Boolean,
        required: [true],
    },
    email_sent: {
        type: Boolean,
        required: [true],
    },
    text_sent: {
        type: Boolean,
        required: [true],
    }
});

const NotificationSchema = new mongoose.Schema({
    email: {
        type: String,
        required: true,
        unique: true,
    },
    notifications: [NotifSchema],
});

module.exports = mongoose.model("Notifications", NotificationSchema);